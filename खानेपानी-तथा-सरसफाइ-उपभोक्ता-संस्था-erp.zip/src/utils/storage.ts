import {
  OrganizationSettings,
  Customer,
  MeterReading,
  BillPayment,
  Loan,
  LoanInstallment,
  BankAccount,
  BankTransaction,
  IncomeEntry,
  ExpenseEntry,
  Staff,
  StaffPayment,
  TankerSale,
  MasterLedgerEntry,
} from '../types';
import { numberToNepaliWords } from './nepaliUtils';

const STORAGE_KEYS = {
  SETTINGS: 'khanepani_settings',
  CUSTOMERS: 'khanepani_customers',
  READINGS: 'khanepani_readings',
  PAYMENTS: 'khanepani_payments',
  LOANS: 'khanepani_loans',
  LOAN_INSTALLMENTS: 'khanepani_loan_installments',
  BANKS: 'khanepani_banks',
  BANK_TXNS: 'khanepani_bank_txns',
  INCOMES: 'khanepani_incomes',
  EXPENSES: 'khanepani_expenses',
  STAFF: 'khanepani_staff',
  STAFF_PAYMENTS: 'khanepani_staff_payments',
  TANKER_SALES: 'khanepani_tanker_sales',
  MASTER_LEDGER: 'khanepani_master_ledger',
  CURRENT_USER: 'khanepani_current_user',
};

export const defaultSettings: OrganizationSettings = {
  orgName: 'श्री जनचेतना खानेपानी तथा सरसफाइ उपभोक्ता संस्था',
  orgAddress: 'धुलिखेल नगरपालिका - ४, काभ्रेपलाञ्चोक',
  orgPhone: '०११-४९०२३४ / ९८५१२३४५६७',
  orgEmail: 'janachetana.khanepani@gmail.com',
  regNo: 'काभ्रे-४५/२०६५',
  panNo: '३०२४५६७८९',
  authorizedPersonName: 'ईन्द्र प्रसाद ढकाल',
  authorizedPersonRole: 'अध्यक्ष',
  currentSystemDateBS: '2081-07-22',
  logoUrl: '',
  waterTariff: {
    minAmount: 150,
    minUnits: 10,
    extraRatePerUnit: 25,
    fineDaysThreshold: 30,
    finePercent: 10,
    fineFixedAmount: 0,
    history: [
      {
        id: 'TAR-01',
        fromDateBS: '2080-01-01',
        toDateBS: '2080-12-30',
        minAmount: 120,
        minUnits: 10,
        extraRatePerUnit: 20,
        fineDaysThreshold: 30,
        finePercent: 10,
        fineFixedAmount: 0,
        note: 'साविक आर्थिक वर्ष २०८०/८१ को दर',
      },
      {
        id: 'TAR-02',
        fromDateBS: '2081-01-01',
        toDateBS: '2081-12-30',
        minAmount: 150,
        minUnits: 10,
        extraRatePerUnit: 25,
        fineDaysThreshold: 30,
        finePercent: 10,
        fineFixedAmount: 0,
        note: 'साधारण सभा २०८० को निर्णयानुसार चालु दर',
      },
    ],
  },
  loanSettings: {
    annualInterestRatePercent: 12,
    history: [
      {
        id: 'LR-01',
        fromDateBS: '2080-01-01',
        toDateBS: '2080-12-30',
        interestRatePercent: 14,
        decisionRef: 'समिति निर्णय नं. ४, २०७९/१२/२८',
      },
      {
        id: 'LR-02',
        fromDateBS: '2081-01-01',
        toDateBS: '2081-12-30',
        interestRatePercent: 12,
        decisionRef: 'समिति निर्णय नं. २, २०८०/१२/२५ (सहुलियत ब्याजदर)',
      },
    ],
  },
  waterTankerSettings: {
    defaultRatePerLiter: 0.35, // रु १७५० प्रति ५००० लिटर
    defaultWagePerLiter: 0.06, // रु ३०० प्रति ५००० लिटर चालक/कर्मचारी ज्याला
    clientRates: [
      {
        id: 'CTR-01',
        clientName: 'हिमालयन रिसोर्ट एण्ड स्पा',
        phone: '९८५१००१२३४',
        ratePerLiter: 0.40,
        wagePerLiter: 0.07,
        fromDateBS: '2081-01-01',
        toDateBS: '2081-12-30',
      },
      {
        id: 'CTR-02',
        clientName: 'काभ्रे अस्पताल तथा नर्सिङ होम',
        phone: '९८४१२२३३४४',
        ratePerLiter: 0.30,
        wagePerLiter: 0.05,
        fromDateBS: '2081-01-01',
        toDateBS: '2081-12-30',
      },
    ],
  },
};

export const defaultCustomers: Customer[] = [
  {
    id: 'CUST-001',
    tapNo: 'धारा-१०१',
    meterNo: 'MTR-8801',
    fullName: 'रामप्रसाद न्यौपाने',
    fatherName: 'केशव राज न्यौपाने',
    grandfatherName: 'हरिलाल न्यौपाने',
    dobBS: '२०२८-०३-१५',
    phone: '9851023456',
    wardNo: '४',
    tole: 'ढकाल टोल',
    address: 'धुलिखेल-४',
    citizenshipNo: '२६-०१-७०-०१२३४',
    citizenshipIssueDateBS: '२०४६-०४-१०',
    plotNo: '२४५/क',
    membershipDateBS: '२०६६-०२-१५',
    previousReading: 142,
    status: 'active',
  },
  {
    id: 'CUST-002',
    tapNo: 'धारा-१०२',
    meterNo: 'MTR-8802',
    fullName: 'सितादेवी श्रेष्ठ',
    fatherName: 'मान बहादुर श्रेष्ठ',
    grandfatherName: 'पदम नारायण श्रेष्ठ',
    dobBS: '२०३५-०६-२१',
    phone: '9841122334',
    wardNo: '४',
    tole: 'चौतारा टोल',
    address: 'धुलिखेल-४',
    citizenshipNo: '२६-०१-७२-०३४१२',
    citizenshipIssueDateBS: '२०५३-०९-१४',
    plotNo: '३१२',
    membershipDateBS: '२०६६-०३-०१',
    previousReading: 215,
    status: 'active',
  },
  {
    id: 'CUST-003',
    tapNo: 'धारा-१०३',
    meterNo: 'MTR-8803',
    fullName: 'हरि बहादुर थापा',
    fatherName: 'शेर बहादुर थापा',
    grandfatherName: 'दिल बहादुर थापा',
    dobBS: '२०३२-११-०५',
    phone: '9860345678',
    wardNo: '४',
    tole: 'धारा टोल',
    address: 'धुलिखेल-४',
    citizenshipNo: '२६-०१-७१-०४५६२',
    citizenshipIssueDateBS: '२०५०-०२-२५',
    plotNo: '१८०',
    membershipDateBS: '२०६७-०१-१०',
    previousReading: 180,
    status: 'active',
  },
  {
    id: 'CUST-004',
    tapNo: 'धारा-१०४',
    meterNo: 'MTR-8804',
    fullName: 'गङ्गा देवी अधिकारी',
    fatherName: 'बालकृष्ण अधिकारी',
    grandfatherName: 'रुद्र प्रसाद अधिकारी',
    dobBS: '२०४०-०१-२८',
    phone: '9849567890',
    wardNo: '४',
    tole: 'विद्यालय टोल',
    address: 'धुलिखेल-४',
    citizenshipNo: '२६-०१-७५-०७८९१',
    citizenshipIssueDateBS: '२०५८-०५-०१',
    plotNo: '५०१',
    membershipDateBS: '२०६८-०५-२०',
    previousReading: 95,
    status: 'active',
  },
  {
    id: 'CUST-005',
    tapNo: 'धारा-१०५',
    meterNo: 'MTR-8805',
    fullName: 'दिनेश कुमार तामाङ',
    fatherName: 'सुकमान तामाङ',
    grandfatherName: 'दोर्जे तामाङ',
    dobBS: '२०४५-०८-१२',
    phone: '9813245678',
    wardNo: '४',
    tole: 'हिले टोल',
    address: 'धुलिखेल-४',
    citizenshipNo: '२६-०१-७८-०९१२३',
    citizenshipIssueDateBS: '२०६३-१०-१५',
    plotNo: '६२०',
    membershipDateBS: '२०७०-०६-०५',
    previousReading: 310,
    status: 'active',
  },
  {
    id: 'CUST-006',
    tapNo: 'धारा-१०६',
    meterNo: 'MTR-8806',
    fullName: 'कमला शर्मा',
    fatherName: 'नारायण प्रसाद शर्मा',
    grandfatherName: 'वेदनाथ शर्मा',
    dobBS: '२०३८-०४-०९',
    phone: '9841890123',
    wardNo: '४',
    tole: 'मन्दिर टोल',
    address: 'धुलिखेल-४',
    citizenshipNo: '२६-०१-७३-०५६७२',
    citizenshipIssueDateBS: '२०५६-०८-२०',
    plotNo: '१४२',
    membershipDateBS: '२०७१-०२-११',
    previousReading: 125,
    status: 'active',
  },
  {
    id: 'CUST-007',
    tapNo: 'धारा-१०७',
    meterNo: 'MTR-8807',
    fullName: 'भरत राज भुजेल',
    fatherName: 'दान बहादुर भुजेल',
    grandfatherName: 'चक्र बहादुर भुजेल',
    dobBS: '२०४२-१०-१७',
    phone: '9861234987',
    wardNo: '४',
    tole: 'वन टोल',
    address: 'धुलिखेल-४',
    citizenshipNo: '२६-०१-७६-०८९०१',
    citizenshipIssueDateBS: '२०६०-११-२९',
    plotNo: '४०५',
    membershipDateBS: '२०७३-०४-२१',
    previousReading: 260,
    status: 'active',
  },
];

export const defaultReadings: MeterReading[] = [
  {
    id: 'MR-2081-07-001',
    customerId: 'CUST-001',
    customerName: 'रामप्रसाद न्यौपाने',
    tapNo: 'धारा-१०१',
    phone: '9851023456',
    yearBS: 2081,
    monthBS: 'कात्तिक',
    entryDateBS: '2081-07-20',
    prevReading: 142,
    currReading: 160,
    consumedUnits: 18,
    baseAmount: 350, // 150 (up to 10) + 8*25 = 350
    fineAmount: 0,
    discountAmount: 0,
    totalBillAmount: 350,
    paidStatus: 'paid',
    paidAmount: 350,
    receiptNo: 'RCP-2081-001',
    paymentDateBS: '2081-07-21',
    paymentMethod: 'नगद (Cash)',
  },
  {
    id: 'MR-2081-07-002',
    customerId: 'CUST-002',
    customerName: 'सितादेवी श्रेष्ठ',
    tapNo: 'धारा-१०२',
    phone: '9841122334',
    yearBS: 2081,
    monthBS: 'कात्तिक',
    entryDateBS: '2081-07-20',
    prevReading: 215,
    currReading: 232,
    consumedUnits: 17,
    baseAmount: 325,
    fineAmount: 0,
    discountAmount: 0,
    totalBillAmount: 325,
    paidStatus: 'unpaid',
    paidAmount: 0,
  },
  {
    id: 'MR-2081-07-003',
    customerId: 'CUST-003',
    customerName: 'हरि बहादुर थापा',
    tapNo: 'धारा-१०३',
    phone: '9860345678',
    yearBS: 2081,
    monthBS: 'कात्तिक',
    entryDateBS: '2081-07-20',
    prevReading: 180,
    currReading: 188,
    consumedUnits: 8,
    baseAmount: 150, // Minimum charge
    fineAmount: 0,
    discountAmount: 0,
    totalBillAmount: 150,
    paidStatus: 'unpaid',
    paidAmount: 0,
  },
  {
    id: 'MR-2081-07-004',
    customerId: 'CUST-004',
    customerName: 'गङ्गा देवी अधिकारी',
    tapNo: 'धारा-१०४',
    phone: '9849567890',
    yearBS: 2081,
    monthBS: 'कात्तिक',
    entryDateBS: '2081-07-20',
    prevReading: 95,
    currReading: 110,
    consumedUnits: 15,
    baseAmount: 275,
    fineAmount: 0,
    discountAmount: 0,
    totalBillAmount: 275,
    paidStatus: 'unpaid',
    paidAmount: 0,
  },
];

export const defaultPayments: BillPayment[] = [
  {
    id: 'PAY-001',
    receiptNo: 'RCP-2081-001',
    readingId: 'MR-2081-07-001',
    customerId: 'CUST-001',
    customerName: 'रामप्रसाद न्यौपाने',
    tapNo: 'धारा-१०१',
    phone: '9851023456',
    dateBS: '2081-07-21',
    monthBS: 'कात्तिक',
    yearBS: 2081,
    unitsConsumed: 18,
    billAmount: 350,
    fineAmount: 0,
    discountAmount: 0,
    netPayable: 350,
    paidAmount: 350,
    paymentMethod: 'नगद (Cash)',
    amountInWordsNepali: 'तीन सय पचास रुपैयाँ मात्र',
    collectedBy: 'सुनिता कार्की (व्यवस्थापक)',
    remarks: 'कात्तिक महिनाको महसुल चुक्ता',
  },
];

export const defaultLoans: Loan[] = [
  {
    id: 'LOAN-2080-001',
    customerId: 'CUST-003',
    customerName: 'हरि बहादुर थापा',
    phone: '9860345678',
    principalAmount: 50000,
    interestRatePercent: 12,
    issueDateBS: '2080-05-10',
    maturityDateBS: '2081-05-10', // OVERDUE!
    purpose: 'खानेपानी पाइप तथा आधुनिक कृषि सिँचाइ विस्तार',
    collateral: 'जग्गाधनी प्रमाणपुर्जा (कित्ता नं १८०)',
    repaidPrincipal: 20000,
    totalInterestPaid: 6000,
    remainingPrincipal: 30000,
    status: 'overdue',
    notes: 'भाखा नाघेको, मोबाइल तथा पत्रमार्फत ताकेता गर्नुपर्ने',
  },
  {
    id: 'LOAN-2081-002',
    customerId: 'CUST-005',
    customerName: 'दिनेश कुमार तामाङ',
    phone: '9813245678',
    principalAmount: 40000,
    interestRatePercent: 12,
    issueDateBS: '2081-02-15',
    maturityDateBS: '2081-11-15', // Active
    purpose: 'घरेलु कुखुरा तथा बंगुर पालन व्यवसाय',
    collateral: 'व्यक्तिगत जमानी (रामप्रसाद न्यौपाने)',
    repaidPrincipal: 10000,
    totalInterestPaid: 3600,
    remainingPrincipal: 30000,
    status: 'active',
    notes: 'नियमित किस्ता बुझाउँदै आएको',
  },
  {
    id: 'LOAN-2080-003',
    customerId: 'CUST-007',
    customerName: 'भरत राज भुजेल',
    phone: '9861234987',
    principalAmount: 25000,
    interestRatePercent: 12,
    issueDateBS: '2080-06-01',
    maturityDateBS: '2081-06-01', // OVERDUE!
    purpose: 'पानी ट्याङ्की निर्माण तथा सरसफाइ पूर्वाधार',
    collateral: 'नागरिकता तथा कित्ता नं ४०५ को लालपुर्जा प्रतिलिपि',
    repaidPrincipal: 5000,
    totalInterestPaid: 3000,
    remainingPrincipal: 20000,
    status: 'overdue',
    notes: 'भाखा नाघिसकेको, अन्तिम सूचना पठाउनुपर्ने',
  },
];

export const defaultLoanInstallments: LoanInstallment[] = [
  {
    id: 'LINST-001',
    receiptNo: 'LRCP-2081-001',
    loanId: 'LOAN-2080-001',
    customerId: 'CUST-003',
    customerName: 'हरि बहादुर थापा',
    dateBS: '2081-02-10',
    principalPaid: 10000,
    interestPaid: 3000,
    totalPaid: 13000,
    remainingPrincipalAfter: 40000,
    paymentMethod: 'नगद (Cash)',
    amountInWordsNepali: 'तेह्र हजार रुपैयाँ मात्र',
    collectedBy: 'सुनिता कार्की',
    remarks: 'पहिलो किस्ता र ब्याज भुक्तानी',
  },
  {
    id: 'LINST-002',
    receiptNo: 'LRCP-2081-002',
    loanId: 'LOAN-2080-001',
    customerId: 'CUST-003',
    customerName: 'हरि बहादुर थापा',
    dateBS: '2081-05-10',
    principalPaid: 10000,
    interestPaid: 3000,
    totalPaid: 13000,
    remainingPrincipalAfter: 30000,
    paymentMethod: 'बैंक / QR',
    amountInWordsNepali: 'तेह्र हजार रुपैयाँ मात्र',
    collectedBy: 'सुनिता कार्की',
    remarks: 'दोस्रो किस्ता भुक्तानी',
  },
];

export const defaultBanks: BankAccount[] = [
  {
    id: 'BANK-01',
    bankName: 'राष्ट्रिय वाणिज्य बैंक लि. (RBB)',
    accountNumber: '१२३०००४५६०१',
    branch: 'धुलिखेल शाखा',
    accountType: 'चल्ती (Current)',
    balance: 485000,
  },
  {
    id: 'BANK-02',
    bankName: 'नेपाल बैंक लिमिटेड (NBL)',
    accountNumber: '०४५०१२३८९०१',
    branch: 'बनेपा शाखा',
    accountType: 'बचत (Saving)',
    balance: 230000,
  },
  {
    id: 'BANK-03',
    bankName: 'एनआईसी एसिया बैंक लि. (NIC Asia)',
    accountNumber: '८९०२३४५६१२९',
    branch: 'धुलिखेल शाखा',
    accountType: 'चल्ती (Current)',
    balance: 145000,
  },
];

export const defaultBankTransactions: BankTransaction[] = [
  {
    id: 'BTXN-001',
    bankId: 'BANK-01',
    bankName: 'राष्ट्रिय वाणिज्य बैंक लि. (RBB)',
    type: 'deposit',
    amount: 150000,
    dateBS: '2081-06-15',
    voucherNo: 'DEP-8901',
    description: 'खानेपानी महसुल तथा पानी बिक्री आम्दानी दाखिला',
    performedBy: 'सुनिता कार्की',
  },
  {
    id: 'BTXN-002',
    bankId: 'BANK-01',
    bankName: 'राष्ट्रिय वाणिज्य बैंक लि. (RBB)',
    type: 'withdraw',
    amount: 35000,
    dateBS: '2081-06-28',
    voucherNo: 'WTH-4412',
    description: 'पाइपलाइन मर्मत तथा कामदार ज्याला भुक्तानी चेक नं ०२३४१',
    performedBy: 'ईन्द्र प्रसाद ढकाल',
  },
  {
    id: 'BTXN-003',
    bankId: 'BANK-02',
    bankName: 'नेपाल बैंक लिमिटेड (NBL)',
    type: 'deposit',
    amount: 50000,
    dateBS: '2081-07-02',
    voucherNo: 'DEP-9012',
    description: 'ऋण किस्ता असुली संकलन रकम जम्मा',
    performedBy: 'सुनिता कार्की',
  },
];

export const defaultIncomes: IncomeEntry[] = [
  {
    id: 'INC-001',
    category: 'मर्मत आम्दानी',
    amount: 12500,
    dateBS: '2081-07-05',
    receivedFrom: 'टोल विकास संस्था तथा उपभोक्ताहरू',
    receiptNo: 'INC-REC-101',
    description: 'मेन पाइपलाइन चुहावट मर्मत सहभागिता शुल्क',
    paymentMode: 'नगद',
    collectedBy: 'सुनिता कार्की',
  },
  {
    id: 'INC-002',
    category: 'नयाँ धारा सेवा शुल्क',
    amount: 30000,
    dateBS: '2081-07-12',
    receivedFrom: 'सुमन तामाङ र २ जना नयाँ उपभोक्ता',
    receiptNo: 'INC-REC-102',
    description: 'नयाँ धारा जडान आवेदन तथा मिटर शुल्क प्रति धारा रु १०,०००',
    paymentMode: 'बैंक / QR',
    collectedBy: 'सुनिता कार्की',
  },
  {
    id: 'INC-003',
    category: 'अनुदान',
    amount: 200000,
    dateBS: '2081-06-25',
    receivedFrom: 'धुलिखेल नगरपालिका कार्यालय',
    receiptNo: 'INC-REC-103',
    description: 'खानेपानी ट्याङ्की मर्मत तथा क्लोरिनेसन सहयोग अनुदान',
    paymentMode: 'बैंक / QR',
    collectedBy: 'ईन्द्र प्रसाद ढकाल',
  },
  {
    id: 'INC-004',
    category: 'सहयोग / चन्दा',
    amount: 15000,
    dateBS: '2081-07-18',
    receivedFrom: 'स्थानीय समाजसेवी श्री बद्री प्रसाद श्रेष्ठ',
    receiptNo: 'INC-REC-104',
    description: 'मुहान संरक्षण तथा वृक्षारोपण सहयोग चन्दा',
    paymentMode: 'नगद',
    collectedBy: 'सुनिता कार्की',
  },
];

export const defaultExpenses: ExpenseEntry[] = [
  {
    id: 'EXP-001',
    category: 'विद्युत महसुल',
    amount: 28500,
    dateBS: '2081-07-08',
    paidTo: 'नेपाल विद्युत प्राधिकरण धुलिखेल वितरण केन्द्र',
    billVoucherNo: 'NEA-BILL-8821',
    description: 'पानी पम्पिङ सब-स्टेशनको आश्विन महिनाको विद्युत महसुल',
    paymentMode: 'बैंक / QR',
    approvedBy: 'ईन्द्र प्रसाद ढकाल',
  },
  {
    id: 'EXP-002',
    category: 'मर्मत खर्च',
    amount: 14200,
    dateBS: '2081-07-14',
    paidTo: 'काभ्रे सप्लायर्स एण्ड हार्डवेयर',
    billVoucherNo: 'INV-3450',
    description: '२ इन्च एचडीपीई पाइप, जोइन्ट कप्लिङ र भल्भ खरिद',
    paymentMode: 'नगद',
    approvedBy: 'ईन्द्र प्रसाद ढकाल',
  },
  {
    id: 'EXP-003',
    category: 'सामग्री खरिद',
    amount: 8500,
    dateBS: '2081-07-15',
    paidTo: 'नेपाल केमिकल इन्डस्ट्रिज',
    billVoucherNo: 'INV-9812',
    description: 'पानी शुद्धिकरण ब्लिचिङ पाउडर र फिटकिरी खरिद',
    paymentMode: 'नगद',
    approvedBy: 'सुनिता कार्की',
  },
  {
    id: 'EXP-004',
    category: 'प्रिन्ट तथा मसलन्द खर्च',
    amount: 4500,
    dateBS: '2081-07-10',
    paidTo: 'शान्ति प्रेस तथा स्टेशनरी',
    billVoucherNo: 'SP-102',
    description: 'मिटर रिडिङ रसिद बुक, लेजर पाना र A4 पेपर',
    paymentMode: 'नगद',
    approvedBy: 'सुनिता कार्की',
  },
  {
    id: 'EXP-005',
    category: 'चिया खाना खाजा खर्च',
    amount: 2800,
    dateBS: '2081-07-16',
    paidTo: 'चौतारी होटल एण्ड क्याफे',
    billVoucherNo: 'V-55',
    description: 'कार्यसमिति बैठक तथा अनुगमन टोली खाजा खर्च',
    paymentMode: 'नगद',
    approvedBy: 'ईन्द्र प्रसाद ढकाल',
  },
];

export const defaultStaff: Staff[] = [
  {
    id: 'STF-01',
    name: 'सुनिता कार्की',
    designation: 'कार्यालय व्यवस्थापक / लेखापाल',
    phone: '9841998877',
    monthlySalary: 28000,
    joinedDateBS: '2075-04-01',
    status: 'active',
  },
  {
    id: 'STF-02',
    name: 'राजेश लामा',
    designation: 'प्राविधिक तथा प्लम्बर',
    phone: '9818776655',
    monthlySalary: 22000,
    joinedDateBS: '2076-06-15',
    status: 'active',
  },
  {
    id: 'STF-03',
    name: 'सुरेश बहादुर पाण्डे',
    designation: 'ट्याङ्कर चालक तथा सहयोगी',
    phone: '9860443322',
    monthlySalary: 18000,
    joinedDateBS: '2078-01-10',
    status: 'active',
  },
];

export const defaultTankerSales: TankerSale[] = [
  {
    id: 'TS-2081-001',
    dateBS: '2081-07-04',
    customerName: 'हिमालयन रिसोर्ट एण्ड स्पा',
    phone: '९८५१००१२३४',
    vehicleNo: 'बा २ ख ४५१२',
    liters: 10000,
    ratePerLiter: 0.40,
    totalAmount: 4000,
    driverStaffId: 'STF-03',
    driverStaffName: 'सुरेश बहादुर पाण्डे',
    wagePerLiter: 0.07,
    driverWage: 700,
    receiptNo: 'TS-REC-01',
    paymentStatus: 'paid',
    remarks: '२ ट्रिप (५०००+५००० लिटर) रिसोर्ट ट्याङ्कीमा ढुवानी',
  },
  {
    id: 'TS-2081-002',
    dateBS: '2081-07-11',
    customerName: 'काभ्रे अस्पताल तथा नर्सिङ होम',
    phone: '९८४१२२३३४४',
    vehicleNo: 'बा २ ख ४५१२',
    liters: 15000,
    ratePerLiter: 0.30,
    totalAmount: 4500,
    driverStaffId: 'STF-03',
    driverStaffName: 'सुरेश बहादुर पाण्डे',
    wagePerLiter: 0.05,
    driverWage: 750,
    receiptNo: 'TS-REC-02',
    paymentStatus: 'paid',
    remarks: '३ ट्रिप आकस्मिक अस्पताल आपूर्ति',
  },
  {
    id: 'TS-2081-003',
    dateBS: '2081-07-18',
    customerName: 'स्थानीय विवाह समारोह (रामकुमार थापा)',
    phone: '९८५१०१२९९९',
    vehicleNo: 'बा २ ख ४५१२',
    liters: 5000,
    ratePerLiter: 0.35,
    totalAmount: 1750,
    driverStaffId: 'STF-03',
    driverStaffName: 'सुरेश बहादुर पाण्डे',
    wagePerLiter: 0.06,
    driverWage: 300,
    receiptNo: 'TS-REC-03',
    paymentStatus: 'paid',
    remarks: '१ ट्रिप खानेपानी वितरण',
  },
];

export const defaultStaffPayments: StaffPayment[] = [
  {
    id: 'SPAY-001',
    staffId: 'STF-01',
    staffName: 'सुनिता कार्की',
    designation: 'कार्यालय व्यवस्थापक / लेखापाल',
    yearBS: 2081,
    monthBS: 'असोज',
    dateBS: '2081-07-01',
    baseSalary: 28000,
    allowance: 2000,
    dressAllowance: 5000,
    festivalBonus: 28000, // दशैं खर्च
    tankerWage: 0,
    totalPaid: 63000,
    receiptNo: 'SAL-2081-06-01',
    remarks: 'असोज महिनाको तलब तथा दशैं खर्च भुक्तानी',
  },
  {
    id: 'SPAY-002',
    staffId: 'STF-03',
    staffName: 'सुरेश बहादुर पाण्डे',
    designation: 'ट्याङ्कर चालक तथा सहयोगी',
    yearBS: 2081,
    monthBS: 'असोज',
    dateBS: '2081-07-02',
    baseSalary: 18000,
    allowance: 1500,
    dressAllowance: 5000,
    festivalBonus: 18000,
    tankerWage: 4200, // असोज महिनाभरिको ट्याङ्कर ज्याला
    totalPaid: 46700,
    receiptNo: 'SAL-2081-06-03',
    remarks: 'असोजको तलब, दशैं भत्ता तथा ट्याङ्कर पानी बिक्री ज्याला',
  },
];

// Helper to get and set local storage safely
export function getStorageData<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return defaultValue;
    return JSON.parse(item) as T;
  } catch (error) {
    console.error(`Error loading key ${key}:`, error);
    return defaultValue;
  }
}

export function setStorageData<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Error saving key ${key}:`, error);
  }
}

// Master functions
export function loadAllKhanepaniData() {
  const settings = getStorageData<OrganizationSettings>(STORAGE_KEYS.SETTINGS, defaultSettings);
  const customers = getStorageData<Customer[]>(STORAGE_KEYS.CUSTOMERS, defaultCustomers);
  const readings = getStorageData<MeterReading[]>(STORAGE_KEYS.READINGS, defaultReadings);
  const payments = getStorageData<BillPayment[]>(STORAGE_KEYS.PAYMENTS, defaultPayments);
  const loans = getStorageData<Loan[]>(STORAGE_KEYS.LOANS, defaultLoans);
  const loanInstallments = getStorageData<LoanInstallment[]>(STORAGE_KEYS.LOAN_INSTALLMENTS, defaultLoanInstallments);
  const banks = getStorageData<BankAccount[]>(STORAGE_KEYS.BANKS, defaultBanks);
  const bankTransactions = getStorageData<BankTransaction[]>(STORAGE_KEYS.BANK_TXNS, defaultBankTransactions);
  const incomes = getStorageData<IncomeEntry[]>(STORAGE_KEYS.INCOMES, defaultIncomes);
  const expenses = getStorageData<ExpenseEntry[]>(STORAGE_KEYS.EXPENSES, defaultExpenses);
  const staff = getStorageData<Staff[]>(STORAGE_KEYS.STAFF, defaultStaff);
  const staffPayments = getStorageData<StaffPayment[]>(STORAGE_KEYS.STAFF_PAYMENTS, defaultStaffPayments);
  const tankerSales = getStorageData<TankerSale[]>(STORAGE_KEYS.TANKER_SALES, defaultTankerSales);

  return {
    settings,
    customers,
    readings,
    payments,
    loans,
    loanInstallments,
    banks,
    bankTransactions,
    incomes,
    expenses,
    staff,
    staffPayments,
    tankerSales,
  };
}

export function resetToSampleData(): void {
  setStorageData(STORAGE_KEYS.SETTINGS, defaultSettings);
  setStorageData(STORAGE_KEYS.CUSTOMERS, defaultCustomers);
  setStorageData(STORAGE_KEYS.READINGS, defaultReadings);
  setStorageData(STORAGE_KEYS.PAYMENTS, defaultPayments);
  setStorageData(STORAGE_KEYS.LOANS, defaultLoans);
  setStorageData(STORAGE_KEYS.LOAN_INSTALLMENTS, defaultLoanInstallments);
  setStorageData(STORAGE_KEYS.BANKS, defaultBanks);
  setStorageData(STORAGE_KEYS.BANK_TXNS, defaultBankTransactions);
  setStorageData(STORAGE_KEYS.INCOMES, defaultIncomes);
  setStorageData(STORAGE_KEYS.EXPENSES, defaultExpenses);
  setStorageData(STORAGE_KEYS.STAFF, defaultStaff);
  setStorageData(STORAGE_KEYS.STAFF_PAYMENTS, defaultStaffPayments);
  setStorageData(STORAGE_KEYS.TANKER_SALES, defaultTankerSales);
}

export function exportFullBackup(): string {
  const fullData = loadAllKhanepaniData();
  const backupObject = {
    version: '1.0.0',
    exportDateBS: fullData.settings.currentSystemDateBS,
    exportTimestamp: new Date().toISOString(),
    ...fullData,
  };
  return JSON.stringify(backupObject, null, 2);
}

export function importFullBackup(jsonString: string): boolean {
  try {
    const data = JSON.parse(jsonString);
    if (!data.settings && !data.customers) {
      throw new Error('अमान्य ब्याकअप फाइल ढाँचा!');
    }
    if (data.settings) setStorageData(STORAGE_KEYS.SETTINGS, data.settings);
    if (data.customers) setStorageData(STORAGE_KEYS.CUSTOMERS, data.customers);
    if (data.readings) setStorageData(STORAGE_KEYS.READINGS, data.readings);
    if (data.payments) setStorageData(STORAGE_KEYS.PAYMENTS, data.payments);
    if (data.loans) setStorageData(STORAGE_KEYS.LOANS, data.loans);
    if (data.loanInstallments) setStorageData(STORAGE_KEYS.LOAN_INSTALLMENTS, data.loanInstallments);
    if (data.banks) setStorageData(STORAGE_KEYS.BANKS, data.banks);
    if (data.bankTransactions) setStorageData(STORAGE_KEYS.BANK_TXNS, data.bankTransactions);
    if (data.incomes) setStorageData(STORAGE_KEYS.INCOMES, data.incomes);
    if (data.expenses) setStorageData(STORAGE_KEYS.EXPENSES, data.expenses);
    if (data.staff) setStorageData(STORAGE_KEYS.STAFF, data.staff);
    if (data.staffPayments) setStorageData(STORAGE_KEYS.STAFF_PAYMENTS, data.staffPayments);
    if (data.tankerSales) setStorageData(STORAGE_KEYS.TANKER_SALES, data.tankerSales);
    return true;
  } catch (error) {
    console.error('Error importing backup:', error);
    return false;
  }
}
