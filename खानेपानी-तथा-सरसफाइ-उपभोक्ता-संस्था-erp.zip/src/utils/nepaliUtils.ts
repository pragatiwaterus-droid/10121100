/**
 * Nepali Date, Number and Currency Utilities
 * Tailored for Nepali Water Supply Committee Management
 */

export const NEPALI_MONTHS = [
  'बैशाख',
  'जेठ',
  'असार',
  'साउन',
  'भदौ',
  'असोज',
  'कात्तिक',
  'मङ्सिर',
  'पुस',
  'माघ',
  'फागुन',
  'चैत',
] as const;

export type NepaliMonth = (typeof NEPALI_MONTHS)[number];

export const NEPALI_YEARS = [2079, 2080, 2081, 2082, 2083, 2084, 2085];

const NEPALI_DIGITS = ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'];

/**
 * Converts English digits to Nepali Devanagari digits
 */
export function toNepaliDigits(val: number | string | undefined | null): string {
  if (val === undefined || val === null) return '';
  const str = String(val);
  return str.replace(/[0-9]/g, (digit) => NEPALI_DIGITS[parseInt(digit, 10)]);
}

/**
 * Converts Nepali Devanagari digits to English digits
 */
export function toEnglishDigits(str: string): string {
  if (!str) return '';
  return str.replace(/[०-९]/g, (char) => String(NEPALI_DIGITS.indexOf(char)));
}

/**
 * Formats a number as Nepali Currency (रु X,XX,XXX.XX)
 */
export function formatNepaliCurrency(amount: number | string | undefined | null, showSymbol = true): string {
  const num = typeof amount === 'string' ? parseFloat(amount) : Number(amount || 0);
  if (isNaN(num)) return showSymbol ? 'रु ०' : '०';
  
  // Format with standard Indian/Nepali numbering grouping (comma after thousands, lakhs, crores)
  const isNegative = num < 0;
  const absNum = Math.abs(num);
  const parts = absNum.toFixed(2).split('.');
  let integerPart = parts[0];
  const decimalPart = parts[1] === '00' ? '' : `.${parts[1]}`;

  if (integerPart.length > 3) {
    const lastThree = integerPart.substring(integerPart.length - 3);
    const otherNumbers = integerPart.substring(0, integerPart.length - 3);
    const formattedOthers = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
    integerPart = formattedOthers + ',' + lastThree;
  }

  const prefix = isNegative ? '- ' : '';
  const formatted = `${prefix}${integerPart}${decimalPart}`;
  return showSymbol ? `रु ${formatted}` : formatted;
}

/**
 * Converts numbers into Nepali Words (रकम अक्षरमा)
 * e.g. 15450 => "पन्ध्र हजार चार सय पचास रुपैयाँ मात्र"
 */
export function numberToNepaliWords(num: number): string {
  if (num === 0) return 'शून्य रुपैयाँ मात्र';
  if (isNaN(num)) return '';

  const units = [
    '', 'एक', 'दुई', 'तीन', 'चार', 'पाँच', 'छ', 'सात', 'आठ', 'नौ', 'दश',
    'एघार', 'बाह्र', 'तेह्र', 'चौध', 'पन्ध्र', 'सोह्र', 'सत्र', 'अठार', 'उन्नाइस', 'बीस',
    'एक्काइस', 'बाइस', 'तेइस', 'चौबिस', 'पच्चिस', 'छब्बीस', 'सत्ताइस', 'अठ्ठाइस', 'उनन्तीस', 'तीस',
    'इकत्तिस', 'बत्तीस', 'तेत्तीस', 'चौँतीस', 'पैँतीस', 'छत्तीस', 'सैँतीस', 'अठतीस', 'उनन्चालीस', 'चालीस',
    'एकचालीस', 'बयालीस', 'त्रिचालीस', 'चवालीस', 'पैँतालीस', 'छयालीस', 'सतचालीस', 'अठचालीस', 'उनन्पचास', 'पचास',
    'एकाउन्न', 'बाउन्न', 'त्रिपन्न', 'चउन्न', 'पचपन्न', 'छपन्न', 'सन्ताउन्न', 'अन्ठाउन्न', 'उनन्साठ्ठी', 'साठ्ठी',
    'एकसट्ठी', 'बासट्ठी', 'त्रिसट्ठी', 'चौंसट्ठी', 'पैंसट्ठी', 'छयसट्ठी', 'सडसट्ठी', 'अठसट्ठी', 'उनन्सत्तरी', 'सत्तरी',
    'एकहत्तर', 'बहत्तर', 'त्रिहत्तर', 'चौहत्तर', 'पचहत्तर', 'छयहत्तर', 'सतहत्तर', 'अठहत्तर', 'उनासी', 'असी',
    'एकासी', 'बयासी', 'त्रियासी', 'चौरासी', 'पचासी', 'छयासी', 'सतासी', 'अठासी', 'उनान्नब्बे', 'नब्बे',
    'एकान्नब्बे', 'बयान्नब्बे', 'त्रियान्नब्बे', 'चौरान्नब्बे', 'पन्चान्नब्बे', 'छयान्नब्बे', 'सन्तान्नब्बे', 'अन्ठान्नब्बे', 'उनान्सय',
  ];

  const intNum = Math.floor(Math.abs(num));
  let remaining = intNum;
  const parts: string[] = [];

  // Crores (करोड)
  if (remaining >= 10000000) {
    const crore = Math.floor(remaining / 10000000);
    remaining %= 10000000;
    parts.push(`${units[crore] || crore} करोड`);
  }

  // Lakhs (लाख)
  if (remaining >= 100000) {
    const lakh = Math.floor(remaining / 100000);
    remaining %= 100000;
    parts.push(`${units[lakh] || lakh} लाख`);
  }

  // Thousands (हजार)
  if (remaining >= 1000) {
    const thousand = Math.floor(remaining / 1000);
    remaining %= 1000;
    parts.push(`${units[thousand] || thousand} हजार`);
  }

  // Hundreds (सय)
  if (remaining >= 100) {
    const hundred = Math.floor(remaining / 100);
    remaining %= 100;
    parts.push(`${units[hundred] || hundred} सय`);
  }

  // Remaining 1-99
  if (remaining > 0) {
    parts.push(units[remaining] || String(remaining));
  }

  const paisa = Math.round((Math.abs(num) - intNum) * 100);
  let result = parts.join(' ').trim();

  if (paisa > 0) {
    result += ` रुपैयाँ ${units[paisa] || paisa} पैसा मात्र`;
  } else {
    result += ' रुपैयाँ मात्र';
  }

  return (num < 0 ? 'ऋणात्मक ' : '') + result;
}

/**
 * Approximate default Nepali BS date generator for standard operational use
 * In production committees, the system date is configurable via Settings
 */
export function getInitialNepaliDate(): string {
  // Return current realistic BS year-month-day
  // Currently Kartik/Mangsir 2081
  const today = new Date();
  const adYear = today.getFullYear();
  // BS is roughly AD + 56.7 years
  const approxBsYear = adYear + 57;
  // Fallback to standard 2081
  return `${Math.min(approxBsYear, 2081)}-07-22`;
}

/**
 * Calculates days difference between two BS dates formatted as YYYY-MM-DD
 */
export function calculateBsDaysDiff(date1Str: string, date2Str: string): number {
  if (!date1Str || !date2Str) return 0;
  try {
    const [y1, m1, d1] = date1Str.split('-').map(Number);
    const [y2, m2, d2] = date2Str.split('-').map(Number);
    if (!y1 || !y2) return 0;
    // Approximating standard 365.25 days / 30.4 days per month for BS difference
    const totalDays1 = y1 * 365 + m1 * 30 + d1;
    const totalDays2 = y2 * 365 + m2 * 30 + d2;
    return totalDays2 - totalDays1;
  } catch {
    return 0;
  }
}

/**
 * Checks if a date is overdue compared to current system date
 */
export function isDateOverdue(maturityDateBS: string, currentSystemDateBS: string): boolean {
  if (!maturityDateBS || !currentSystemDateBS) return false;
  return maturityDateBS < currentSystemDateBS;
}

/**
 * Calculate loan interest based on principal, annual rate %, and days
 */
export function calculateSimpleInterest(
  principal: number,
  ratePercent: number,
  fromDateBS: string,
  toDateBS: string
): number {
  const days = Math.max(0, calculateBsDaysDiff(fromDateBS, toDateBS));
  if (days <= 0 || principal <= 0 || ratePercent <= 0) return 0;
  const interest = (principal * ratePercent * days) / (365 * 100);
  return Math.round(interest);
}

/**
 * Calculate water bill amount based on consumed units and committee tariff rules
 */
export function calculateWaterBill(
  units: number,
  minAmount: number,
  minUnits: number,
  extraRatePerUnit: number
): number {
  if (units <= 0) return minAmount;
  if (units <= minUnits) {
    return minAmount;
  }
  const extraUnits = units - minUnits;
  return minAmount + extraUnits * extraRatePerUnit;
}

/**
 * Generate formatted WhatsApp message for consumer bill notice
 */
export function generateBillWhatsAppText(
  orgName: string,
  customerName: string,
  tapNo: string,
  monthBS: string,
  yearBS: number,
  prevReading: number,
  currReading: number,
  consumedUnits: number,
  billAmount: number,
  fineAmount: number,
  totalPayable: number,
  phone: string
): string {
  return (
    `*${orgName}*\n` +
    `नमस्ते ${customerName} ज्यू,\n` +
    `तपाईंको धारा नं: ${tapNo} को ${monthBS} ${yearBS} को खानेपानी मिटर रिडिङ विवरण:\n` +
    `--------------------------------\n` +
    `• साविक अङ्क: ${prevReading}\n` +
    `• हालको अङ्क: ${currReading}\n` +
    `• कुल खपत युनिट: ${consumedUnits} युनिट\n` +
    `• महसुल रकम: रु ${billAmount}\n` +
    (fineAmount > 0 ? `• जरिवाना: रु ${fineAmount}\n` : '') +
    `*कुल बुझाउनुपर्ने रकम: रु ${totalPayable}*\n` +
    `--------------------------------\n` +
    `कृपया समयमै कार्यालय वा बैंक/QR मार्फत महसुल भुक्तानी गरी जरिवानाबाट बच्नुहोला। धन्यवाद!`
  );
}

/**
 * Safe WhatsApp Web URL creator with internationalized Nepali numbers (+977)
 */
export function createWhatsAppUrl(phone: string, text: string): string {
  let cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length === 10) {
    cleanPhone = '977' + cleanPhone;
  }
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
}

/**
 * Loan overdue notification WhatsApp message
 */
export function generateLoanOverdueWhatsAppText(
  orgName: string,
  customerName: string,
  loanId: string,
  remainingPrincipal: number,
  maturityDateBS: string,
  contactPhone: string
): string {
  return (
    `*${orgName} - ऋण सूचना*\n` +
    `आदरणीय सदस्य ${customerName} ज्यू,\n` +
    `तपाईंले लिनुभएको ऋण (नं: ${loanId}) को भुक्तानी म्याद ${maturityDateBS} मा समाप्त भइसकेको छ।\n` +
    `• बाँकी सावाँ: रु ${remainingPrincipal.toLocaleString()}\n` +
    `कृपया यथाशीघ्र संस्थाको कार्यालयमा सम्पर्क गरी किस्ता तथा ब्याज भुक्तानी गर्नुहुन अनुरोध गरिन्छ।\n` +
    `सम्पर्क फोन: ${contactPhone}`
  );
}
