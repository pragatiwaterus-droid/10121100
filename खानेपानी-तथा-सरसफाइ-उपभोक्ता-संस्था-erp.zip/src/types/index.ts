export interface OrganizationSettings {
  orgName: string;
  orgAddress: string;
  orgPhone: string;
  orgEmail: string;
  regNo: string;
  panNo: string;
  authorizedPersonName: string;
  authorizedPersonRole: string;
  logoUrl?: string;
  currentSystemDateBS: string; // e.g. "2081-07-22"
  waterTariff: WaterTariffSettings;
  loanSettings: LoanSettings;
  waterTankerSettings: WaterTankerSettings;
}

export interface TariffRateHistory {
  id: string;
  fromDateBS: string;
  toDateBS: string;
  minAmount: number;
  minUnits: number;
  extraRatePerUnit: number;
  fineDaysThreshold: number;
  finePercent: number;
  fineFixedAmount: number;
  note?: string;
}

export interface WaterTariffSettings {
  minAmount: number; // न्यूनतम रकम e.g. रु १५०
  minUnits: number; // न्यूनतम युनिट सीमा e.g. १० युनिट
  extraRatePerUnit: number; // अतिरिक्त युनिट शुल्क दर e.g. रु २५
  fineDaysThreshold: number; // रिडिङ भएपछि कति दिनमा जरिवाना लाग्ने e.g. ३० दिन
  finePercent: number; // जरिवाना प्रतिशत e.g. १०%
  fineFixedAmount: number; // अतिरिक्त जरिवाना रकम
  history: TariffRateHistory[];
}

export interface LoanRateHistory {
  id: string;
  fromDateBS: string;
  toDateBS: string;
  interestRatePercent: number;
  decisionRef: string; // समितिको निर्णय मिति / निर्णय नं
}

export interface LoanSettings {
  annualInterestRatePercent: number; // ब्याजदर e.g. १२%
  history: LoanRateHistory[];
}

export interface TankerClientRate {
  id: string;
  clientName: string;
  phone: string;
  ratePerLiter: number; // बिक्री दर
  wagePerLiter: number; // ज्याला दर
  fromDateBS: string;
  toDateBS: string;
}

export interface WaterTankerSettings {
  defaultRatePerLiter: number; // साधारण बिक्री दर e.g. रु ०.३५ / लिटर (रु १७५० प्रति ५००० लिटर)
  defaultWagePerLiter: number; // चालक/कर्मचारी ज्याला दर e.g. रु ०.०६ / लिटर (रु ३०० प्रति ५००० लिटर)
  clientRates: TankerClientRate[];
}

export interface Customer {
  id: string; // e.g. "CUST-001"
  tapNo: string; // धारा नं
  meterNo: string; // मिटर नं
  fullName: string; // ग्राहकको नाम
  fatherName: string; // बुवाको नाम
  grandfatherName: string; // बाजेको नाम
  dobBS: string; // जन्ममिति (BS)
  phone: string; // फोन नं
  wardNo: string; // वडा नं
  tole: string; // टोल
  address: string; // ठेगाना
  citizenshipNo: string; // नागरिकता नं
  citizenshipIssueDateBS: string; // नागरिकता जारी मिति
  plotNo: string; // जग्गा कित्ता नं
  membershipDateBS: string; // ग्राहक बनेको मिति (अटो)
  previousReading: number; // साविक अङ्क
  status: 'active' | 'inactive';
  notes?: string;
}

export interface MeterReading {
  id: string;
  customerId: string;
  customerName: string;
  tapNo: string;
  phone: string;
  yearBS: number; // 2081
  monthBS: string; // "बैशाख", "कार्तिक" etc.
  entryDateBS: string;
  prevReading: number;
  currReading: number;
  consumedUnits: number;
  baseAmount: number;
  fineAmount: number;
  discountAmount: number;
  totalBillAmount: number;
  paidStatus: 'unpaid' | 'paid' | 'partial';
  paidAmount: number;
  receiptNo?: string;
  paymentDateBS?: string;
  paymentMethod?: string;
}

export interface BillPayment {
  id: string;
  receiptNo: string; // RCP-2081-XXXX
  readingId?: string;
  customerId: string;
  customerName: string;
  tapNo: string;
  phone: string;
  dateBS: string;
  monthBS: string;
  yearBS: number;
  unitsConsumed: number;
  billAmount: number;
  fineAmount: number;
  discountAmount: number;
  netPayable: number;
  paidAmount: number;
  paymentMethod: 'नगद (Cash)' | 'बैंक / QR (Fonepay)' | 'चेक (Cheque)';
  amountInWordsNepali: string;
  collectedBy: string;
  remarks?: string;
}

export interface Loan {
  id: string; // e.g. "LOAN-2081-001"
  customerId: string;
  customerName: string;
  phone: string;
  principalAmount: number; // ऋण लगानी रकम
  interestRatePercent: number; // ब्याजदर
  issueDateBS: string; // लगानी मिति
  maturityDateBS: string; // म्याद सकिने मिति
  purpose: string; // उद्देश्य (जस्तै: कृषि, खानेपानी जडान, पशुपालन, घरेलु व्यवसाय)
  collateral: string; // धितो / जमानी
  repaidPrincipal: number; // फिर्ता भएको सावाँ
  totalInterestPaid: number; // प्राप्त ब्याज
  remainingPrincipal: number; // बाँकी सावाँ
  status: 'active' | 'closed' | 'overdue';
  notes?: string;
}

export interface LoanInstallment {
  id: string;
  receiptNo: string; // LRCP-2081-XXXX
  loanId: string;
  customerId: string;
  customerName: string;
  dateBS: string;
  principalPaid: number; // तिरेको सावाँ
  interestPaid: number; // तिरेको ब्याज
  totalPaid: number; // कुल भुक्तानी
  remainingPrincipalAfter: number; // भुक्तानीपछिको बाँकी सावाँ
  paymentMethod: 'नगद (Cash)' | 'बैंक / QR' | 'चेक';
  amountInWordsNepali: string;
  collectedBy: string;
  remarks?: string;
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  branch: string;
  accountType: 'बचत (Saving)' | 'चल्ती (Current)';
  balance: number;
}

export interface BankTransaction {
  id: string;
  bankId: string;
  bankName: string;
  type: 'deposit' | 'withdraw'; // जम्मा वा झिकेको
  amount: number;
  dateBS: string;
  voucherNo: string;
  description: string;
  performedBy: string;
}

export type IncomeCategory =
  | 'मर्मत आम्दानी'
  | 'नयाँ धारा सेवा शुल्क'
  | 'अनुदान'
  | 'सहयोग / चन्दा'
  | 'मिटर नामसारी शुल्क'
  | 'अन्य आम्दानी';

export interface IncomeEntry {
  id: string;
  category: IncomeCategory;
  amount: number;
  dateBS: string;
  receivedFrom: string;
  receiptNo: string;
  description: string;
  paymentMode: 'नगद' | 'बैंक / QR' | 'चेक';
  collectedBy: string;
}

export type ExpenseCategory =
  | 'विद्युत महसुल'
  | 'मर्मत खर्च'
  | 'सामग्री खरिद'
  | 'लेखा परीक्षण शुल्क'
  | 'गाडीभाडा खर्च'
  | 'चिया खाना खाजा खर्च'
  | 'साधारण सभा खर्च'
  | 'प्रिन्ट तथा मसलन्द खर्च'
  | 'रिचार्ज खर्च'
  | 'पेट्रोल / इन्धन खर्च'
  | 'अन्य खर्चहरू';

export interface ExpenseEntry {
  id: string;
  category: ExpenseCategory;
  amount: number;
  dateBS: string;
  paidTo: string;
  billVoucherNo: string;
  description: string;
  paymentMode: 'नगद' | 'बैंक / QR' | 'चेक';
  approvedBy: string;
}

export interface Staff {
  id: string;
  name: string;
  designation: string; // पद
  phone: string;
  monthlySalary: number;
  joinedDateBS: string;
  status: 'active' | 'inactive';
}

export interface StaffPayment {
  id: string;
  staffId: string;
  staffName: string;
  designation: string;
  yearBS: number;
  monthBS: string;
  dateBS: string;
  baseSalary: number; // तलब
  allowance: number; // सेवा सुविधा भत्ता
  dressAllowance: number; // पोशाक खर्च
  festivalBonus: number; // चाडपर्व खर्च
  tankerWage: number; // गाडीमा पानी बिक्री गरेको ज्याला
  totalPaid: number;
  receiptNo: string;
  remarks?: string;
}

export interface TankerSale {
  id: string;
  dateBS: string;
  customerName: string;
  phone: string;
  vehicleNo: string;
  liters: number;
  ratePerLiter: number;
  totalAmount: number;
  driverStaffId: string;
  driverStaffName: string;
  wagePerLiter: number;
  driverWage: number;
  receiptNo: string;
  paymentStatus: 'paid' | 'unpaid';
  remarks?: string;
}

export interface MasterLedgerEntry {
  id: string;
  dateBS: string;
  module: 'पानी महसुल' | 'ऋण लगानी' | 'किस्ता असुली' | 'बैंक कारोबार' | 'आम्दानी' | 'खर्च' | 'कर्मचारी तलब' | 'गाडी पानी बिक्री';
  type: 'आम्दानी (Credit)' | 'खर्च (Debit)';
  customerId?: string;
  partyName: string;
  amount: number;
  referenceNo: string;
  description: string;
  paymentMode: string;
}

export interface UserSession {
  username: string;
  fullName: string;
  role: 'व्यवस्थापक (Admin)' | 'कर्मचारी (Staff)' | 'अध्यक्ष / पदाधिकारी';
  isLoggedIn: boolean;
}
